function main()
{
	var instanceOne = new ClassOne();
	var instanceTwo = new ClassTwo();
}
