
class ClassTwo
{
	constructor()
	{
		this.valueOne = 1;
		this.valueTwo = 2;
	}

	static staticOne()
	{}

	methodOne()
	{
		// Do nothing.
	}

	methodTwo()
	{
		var one = 1;
		var two = 2;
		return one + two;
	}
}
